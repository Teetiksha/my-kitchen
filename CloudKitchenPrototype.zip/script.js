const cart = [];

function addToCart(item, price) {
  cart.push({ item, price });
  updateCart();
}

function updateCart() {
  const list = document.getElementById("cartItems");
  const totalEl = document.getElementById("total");
  list.innerHTML = "";
  let total = 0;
  cart.forEach(({ item, price }) => {
    const li = document.createElement("li");
    li.textContent = `${item} - ₹${price}`;
    list.appendChild(li);
    total += price;
  });
  totalEl.textContent = `Total: ₹${total}`;
}

function submitOrder() {
  const phoneNumber = "91XXXXXXXXXX"; // Replace with your number
  const orderText = cart.map(({ item, price }) => `- ${item} ₹${price}`).join("%0A");
  const total = cart.reduce((sum, { price }) => sum + price, 0);
  const message = `Hello, I want to order:%0A${orderText}%0A%0ATotal: ₹${total}`;
  const whatsappUrl = `https://wa.me/${phoneNumber}?text=${message}`;
  window.open(whatsappUrl, "_blank");
}
