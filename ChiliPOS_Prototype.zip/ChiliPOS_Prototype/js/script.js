
// Example script to handle cart or order summary
document.addEventListener('DOMContentLoaded', () => {
  console.log("POS system loaded");
});
